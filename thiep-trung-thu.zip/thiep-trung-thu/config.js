// =====================================================================
//  CHỈ CẦN SỬA FILE NÀY — mọi chữ trong thiệp đều lấy từ đây.
//  Chỗ nào có ✏️ là chỗ nên thay bằng chuyện riêng của hai bạn.
// =====================================================================

export const CONFIG = {
  herName: 'Tata',        // ✏️ tên / biệt danh của cô ấy, ví dụ: 'Bống', 'Mèo con', 'Linh'
  fromName: 'Sony',      // ✏️ tên bạn (ký cuối thư)

  // 4 câu hiện dần khi cô ấy giữ vầng trăng (thơ lục bát 6-8)
  poem: [
    'Trăng rằm tháng Tám lên cao',
    'Soi đường anh tới hôm nào gặp em',
    'Bao nhiêu đèn sáng bên thềm',
    'Không bằng đôi mắt dịu êm em cười',
  ],

  // Lời nhắn khi chạm vào từng thứ trong khung cảnh 3D.
  // ✏️ Mẹo: mỗi lời nhắn gắn với MỘT kỷ niệm thật (lần đầu gặp, món hai đứa hay ăn...) sẽ chạm hơn nhiều.
  secrets: {
    moon: {
      title: 'Vầng trăng',
      text: 'Người ta nói đêm rằm là lúc trăng tròn nhất năm. Anh thì thấy năm nay trăng tròn hơn mọi năm, chắc tại năm nay có em.',
    },
    cakes: {
      title: 'Mâm cỗ Trung Thu',
      text: 'Bánh nướng nhân trứng muối, bánh dẻo đậu xanh. Miếng có hai lòng đỏ anh để phần em rồi đó. Trung Thu năm sau, năm sau nữa, mình vẫn ngồi ăn bánh chung như vầy nha.',
    },
    lantern: {
      title: 'Dây đèn lồng',
      text: 'Mỗi chiếc đèn là một điều anh muốn cảm ơn em: vì đã kiên nhẫn với anh, vì đã dịu dàng, và vì đã chọn anh.',
    },
    lion: {
      title: 'Múa lân',
      text: 'Tùng tùng cắc! Chúc em một mùa Trung Thu rộn ràng như tiếng trống lân, và một năm lúc nào cũng có lý do để cười.',
    },
    rabbit: {
      title: 'Thỏ Ngọc',
      text: 'Thỏ Ngọc ngồi canh trăng suốt cả năm. Còn anh xin được canh giấc ngủ, canh bữa ăn, canh cả những ngày em mệt.',
    },
    star: {
      title: 'Đèn ông sao',
      text: 'Hồi nhỏ ai cũng mong có một chiếc đèn ông sao. Lớn rồi, điều anh mong nhất là được cùng em đi rước đèn mỗi mùa trăng.',
    },
  },

  // Lá thư mở khóa khi tìm đủ 6 điều bí mật. Mỗi dòng trống = một đoạn mới.
  // ✏️ Đây là phần quan trọng nhất — nên tự viết bằng giọng của bạn.
  letter: `Trung Thu năm nay Sony không mua quà sớm choa em được nên làm cái này bù lại cho em coi cho vui nhá, lần sau sẽ chuẩn bị sớm hơn ha`,

  // Lời nhắn hiện ra khi chạm vào hộp quà (hoặc nút quà trên cùng)
  gift: {
    intro: 'Anh có chuẩn bị thêm một món quà. Tới sớm hơn dự kiến nhưng mà thui em thích là được rùi hehee',
  },

  photo: null,  // ✏️ ví dụ 'anh-em.jpg' (để cùng thư mục) — ảnh hai đứa sẽ hiện trong vầng trăng khi chạm vào trăng
  music: null,  // ✏️ ví dụ 'bai-hat.mp3' — bài hát của hai đứa. Để null thì thiệp tự chơi nhạc ngũ cung.
};
